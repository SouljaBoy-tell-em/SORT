#include <stdio.h>


typedef Elem_t double;


struct stack {

	Elem_t * data;
	size_t size;
	size_t capacity;
} 

int main (void) {



	return 0;
}